"use client";

import { useState } from "react";
import { X, Key, ExternalLink, Eye, EyeOff, CheckCircle } from "lucide-react";

interface Props {
  apiKey: string;
  onSave: (key: string) => void;
  onClose: () => void;
}

export default function SettingsModal({ apiKey, onSave, onClose }: Props) {
  const [value, setValue] = useState(apiKey);
  const [show, setShow] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    onSave(value.trim());
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-md bg-panel border border-border-bright rounded-2xl shadow-2xl shadow-black/60 animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan/10 border border-cyan/20 flex items-center justify-center">
              <Key size={15} className="text-cyan" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-bright">Settings</h2>
              <p className="text-xs text-dim">Configure your API access</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-dim hover:text-bright hover:bg-border transition-all"
          >
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-5">
          {/* API Key */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-soft">
              OpenRouter API Key
            </label>
            <div className="relative">
              <input
                type={show ? "text" : "password"}
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder="sk-or-v1-..."
                className="
                  w-full bg-surface border border-border-bright rounded-xl
                  px-4 py-3 pr-12 text-sm font-mono text-bright
                  placeholder:text-muted
                  focus:outline-none focus:border-cyan/50 focus:ring-1 focus:ring-cyan/20
                  transition-all duration-200
                "
              />
              <button
                type="button"
                onClick={() => setShow((p) => !p)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-dim hover:text-soft transition-colors"
              >
                {show ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            <p className="text-xs text-dim leading-relaxed">
              Your key is stored locally in your browser and never sent to our servers.
            </p>
          </div>

          {/* Info box */}
          <div className="bg-cyan/5 border border-cyan/15 rounded-xl p-4">
            <p className="text-xs text-soft leading-relaxed">
              Get your free API key from OpenRouter. It gives you access to 200+ models
              including GPT-4o, Claude 3.5, Gemini, and Llama.
            </p>
            <a
              href="https://openrouter.ai/keys"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 mt-2 text-xs text-cyan hover:underline"
            >
              Get API Key <ExternalLink size={11} />
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="flex gap-2 p-5 pt-0">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-border-bright text-sm text-soft hover:text-bright hover:bg-border transition-all"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 flex items-center justify-center gap-2
              bg-cyan text-void hover:bg-cyan/90 active:scale-95"
          >
            {saved ? (
              <>
                <CheckCircle size={15} /> Saved!
              </>
            ) : (
              "Save Key"
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

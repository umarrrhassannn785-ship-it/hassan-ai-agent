"use client";

import { Bot, Zap, Shield, Globe } from "lucide-react";

interface Props {
  onPrompt: (text: string) => void;
  hasApiKey: boolean;
  onOpenSettings: () => void;
}

const STARTER_PROMPTS = [
  { icon: "💡", label: "Brainstorm ideas for a SaaS product" },
  { icon: "🐍", label: "Write a FastAPI CRUD app with SQLAlchemy" },
  { icon: "📊", label: "Analyze and explain this dataset structure" },
  { icon: "✍️", label: "Write a compelling product launch email" },
  { icon: "🔐", label: "Explain OAuth2 flow with PKCE" },
  { icon: "🤖", label: "Build a simple Python chatbot" },
];

const FEATURES = [
  { icon: Zap, label: "Streaming responses" },
  { icon: Globe, label: "7+ AI models" },
  { icon: Shield, label: "Key stored locally" },
];

export default function WelcomeScreen({ onPrompt, hasApiKey, onOpenSettings }: Props) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-4 py-8 animate-fade-in">
      {/* Logo */}
      <div className="relative mb-6">
        <div className="w-16 h-16 rounded-2xl bg-cyan/10 border border-cyan/20 flex items-center justify-center glow-cyan">
          <Bot size={28} className="text-cyan" />
        </div>
        <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan border-2 border-void shimmer" />
      </div>

      <h1 className="text-2xl font-bold text-bright mb-1 text-center font-mono">
        AI Agent
      </h1>
      <p className="text-sm text-dim text-center mb-8 max-w-xs leading-relaxed">
        Multi-model AI chat. Switch between GPT-4, Claude, Gemini, and more in seconds.
      </p>

      {/* Features */}
      <div className="flex items-center gap-4 mb-8">
        {FEATURES.map(({ icon: Icon, label }) => (
          <div key={label} className="flex items-center gap-1.5 text-xs text-muted font-mono">
            <Icon size={12} className="text-cyan/60" />
            {label}
          </div>
        ))}
      </div>

      {/* API Key Warning */}
      {!hasApiKey && (
        <div className="w-full max-w-sm mb-6 bg-amber-500/8 border border-amber-500/20 rounded-xl p-4">
          <p className="text-xs text-amber-400/90 leading-relaxed text-center">
            No API key set.{" "}
            <button
              onClick={onOpenSettings}
              className="underline underline-offset-2 hover:text-amber-300 transition-colors"
            >
              Add your OpenRouter key
            </button>{" "}
            to start chatting.
          </p>
        </div>
      )}

      {/* Starter prompts */}
      <div className="w-full max-w-lg">
        <p className="text-xs text-muted font-mono uppercase tracking-wider text-center mb-3">
          Try asking
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {STARTER_PROMPTS.map((p) => (
            <button
              key={p.label}
              onClick={() => onPrompt(p.label)}
              className="
                flex items-center gap-2.5 text-left px-3.5 py-3 rounded-xl
                border border-border-bright bg-panel
                hover:border-cyan/30 hover:bg-cyan/4 hover:text-bright
                transition-all duration-200 group text-sm text-soft
              "
            >
              <span className="text-base flex-shrink-0">{p.icon}</span>
              <span className="leading-tight text-xs">{p.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

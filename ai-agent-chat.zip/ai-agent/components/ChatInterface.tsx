"use client";

import { useEffect, useRef, useState } from "react";
import { Settings, Menu, Plus, AlertCircle, X } from "lucide-react";
import { useChat } from "@/hooks/useChat";
import Sidebar from "./Sidebar";
import MessageBubble from "./MessageBubble";
import ChatInput from "./ChatInput";
import ModelSelector from "./ModelSelector";
import SettingsModal from "./SettingsModal";
import WelcomeScreen from "./WelcomeScreen";

export default function ChatInterface() {
  const {
    conversations,
    activeConversation,
    activeId,
    setActiveId,
    isStreaming,
    error,
    clearError,
    apiKey,
    saveApiKey,
    selectedModel,
    setSelectedModel,
    newConversation,
    deleteConversation,
    renameConversation,
    sendMessage,
    stopStreaming,
  } = useChat();

  const [showSettings, setShowSettings] = useState(false);
  const [mobileSidebar, setMobileSidebar] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const messagesRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeConversation?.messages]);

  const handleSend = async (content: string) => {
    if (!activeId) {
      const id = newConversation();
      // give state time to update
      setTimeout(() => sendMessage(content), 50);
    } else {
      sendMessage(content);
    }
  };

  const handlePrompt = (text: string) => {
    sendMessage(text);
  };

  const messages = activeConversation?.messages ?? [];
  const showWelcome = messages.length === 0;

  return (
    <div className="flex h-screen overflow-hidden bg-void">
      {/* Desktop Sidebar */}
      <div className="hidden md:flex w-64 lg:w-72 flex-shrink-0">
        <Sidebar
          conversations={conversations}
          activeId={activeId}
          onSelect={setActiveId}
          onNew={newConversation}
          onDelete={deleteConversation}
          onRename={renameConversation}
        />
      </div>

      {/* Mobile Sidebar Overlay */}
      {mobileSidebar && (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setMobileSidebar(false)}
          />
          <div className="relative w-72 sidebar-transition animate-slide-up">
            <Sidebar
              conversations={conversations}
              activeId={activeId}
              onSelect={setActiveId}
              onNew={newConversation}
              onDelete={deleteConversation}
              onRename={renameConversation}
              onClose={() => setMobileSidebar(false)}
              mobile
            />
          </div>
        </div>
      )}

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="flex items-center justify-between px-4 py-3 border-b border-border bg-surface/80 backdrop-blur-md flex-shrink-0">
          <div className="flex items-center gap-2">
            {/* Mobile menu */}
            <button
              onClick={() => setMobileSidebar(true)}
              className="md:hidden w-8 h-8 flex items-center justify-center rounded-lg text-dim hover:text-bright hover:bg-border transition-all"
            >
              <Menu size={18} />
            </button>

            {/* Conversation title */}
            <div className="max-w-xs">
              {activeConversation ? (
                <p className="text-sm font-medium text-soft truncate">
                  {activeConversation.title}
                </p>
              ) : (
                <p className="text-sm text-muted font-mono">Select or start a chat</p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <ModelSelector
              value={selectedModel}
              onChange={setSelectedModel}
              disabled={isStreaming}
            />

            {/* New chat (mobile shortcut) */}
            <button
              onClick={newConversation}
              className="md:hidden w-8 h-8 flex items-center justify-center rounded-lg text-dim hover:text-bright hover:bg-border transition-all"
            >
              <Plus size={16} />
            </button>

            <button
              onClick={() => setShowSettings(true)}
              className={`
                w-8 h-8 flex items-center justify-center rounded-lg transition-all
                ${apiKey
                  ? "text-dim hover:text-bright hover:bg-border"
                  : "text-amber-400 hover:text-amber-300 hover:bg-amber-400/10 animate-pulse-slow"
                }
              `}
            >
              <Settings size={16} />
            </button>
          </div>
        </header>

        {/* Error banner */}
        {error && (
          <div className="flex items-center justify-between px-4 py-2.5 bg-red-500/10 border-b border-red-500/20 animate-fade-in">
            <div className="flex items-center gap-2 text-red-400 text-sm">
              <AlertCircle size={14} />
              <span>{error}</span>
            </div>
            <button onClick={clearError} className="text-red-400/60 hover:text-red-400 transition-colors">
              <X size={14} />
            </button>
          </div>
        )}

        {/* Messages / Welcome */}
        <div
          ref={messagesRef}
          className="flex-1 overflow-y-auto"
          style={{ scrollbarGutter: "stable" }}
        >
          {showWelcome ? (
            <WelcomeScreen
              onPrompt={handlePrompt}
              hasApiKey={!!apiKey}
              onOpenSettings={() => setShowSettings(true)}
            />
          ) : (
            <div className="max-w-3xl mx-auto w-full py-4 space-y-1">
              {messages.map((msg, i) => (
                <MessageBubble
                  key={msg.id}
                  message={msg}
                  isStreaming={isStreaming && i === messages.length - 1}
                />
              ))}
              <div ref={bottomRef} className="h-4" />
            </div>
          )}
        </div>

        {/* Input */}
        <div className="border-t border-border bg-surface/60 backdrop-blur-md flex-shrink-0">
          <div className="max-w-3xl mx-auto w-full">
            <ChatInput
              onSend={handleSend}
              onStop={stopStreaming}
              isStreaming={isStreaming}
              disabled={!apiKey}
              placeholder={
                apiKey ? "Message AI Agent... (Enter to send)" : "Add your OpenRouter API key to chat"
              }
            />
          </div>
        </div>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <SettingsModal
          apiKey={apiKey}
          onSave={saveApiKey}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  );
}

"use client";

import { useState, useRef, useEffect } from "react";
import { ChevronDown, Cpu } from "lucide-react";
import { AVAILABLE_MODELS, OpenRouterModel } from "@/types";

interface Props {
  value: string;
  onChange: (model: string) => void;
  disabled?: boolean;
}

export default function ModelSelector({ value, onChange, disabled }: Props) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const current = AVAILABLE_MODELS.find((m) => m.id === value) ?? AVAILABLE_MODELS[0];

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => !disabled && setOpen((p) => !p)}
        disabled={disabled}
        className={`
          flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-mono
          border border-border-bright bg-panel
          hover:border-cyan/50 hover:bg-panel transition-all duration-200
          disabled:opacity-40 disabled:cursor-not-allowed
          ${open ? "border-cyan/50 text-cyan" : "text-soft"}
        `}
      >
        <Cpu size={13} />
        <span className="hidden sm:inline">{current.name}</span>
        <span className="sm:hidden">Model</span>
        <ChevronDown
          size={13}
          className={`transition-transform duration-200 ${open ? "rotate-180" : ""}`}
        />
      </button>

      {open && (
        <div className="
          absolute top-full left-0 mt-2 w-56 z-50
          bg-panel border border-border-bright rounded-xl
          shadow-2xl shadow-black/50 overflow-hidden
          animate-slide-up
        ">
          <div className="px-3 py-2 border-b border-border">
            <p className="text-xs text-dim font-mono uppercase tracking-wider">Select Model</p>
          </div>
          <div className="py-1 max-h-80 overflow-y-auto">
            {AVAILABLE_MODELS.map((model: OpenRouterModel) => (
              <button
                key={model.id}
                onClick={() => { onChange(model.id); setOpen(false); }}
                className={`
                  w-full text-left px-3 py-2.5 flex flex-col gap-0.5
                  hover:bg-border transition-colors duration-150
                  ${model.id === value ? "bg-cyan/5" : ""}
                `}
              >
                <div className="flex items-center justify-between">
                  <span className={`text-sm font-medium ${model.id === value ? "text-cyan" : "text-bright"}`}>
                    {model.name}
                  </span>
                  {model.id === value && (
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan" />
                  )}
                </div>
                <span className="text-xs text-dim font-mono">
                  {(model.context_length / 1000).toFixed(0)}k ctx
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

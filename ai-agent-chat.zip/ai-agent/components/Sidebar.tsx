"use client";

import { useState } from "react";
import {
  Plus,
  MessageSquare,
  Trash2,
  Edit3,
  Check,
  X,
  Bot,
  ChevronLeft,
} from "lucide-react";
import { Conversation } from "@/types";

interface Props {
  conversations: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
  onRename: (id: string, title: string) => void;
  onClose?: () => void;
  mobile?: boolean;
}

function timeAgo(date: Date): string {
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(date).toLocaleDateString();
}

export default function Sidebar({
  conversations,
  activeId,
  onSelect,
  onNew,
  onDelete,
  onRename,
  onClose,
  mobile,
}: Props) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const startEdit = (c: Conversation) => {
    setEditingId(c.id);
    setEditValue(c.title);
  };

  const commitEdit = () => {
    if (editingId && editValue.trim()) {
      onRename(editingId, editValue.trim());
    }
    setEditingId(null);
  };

  return (
    <div className="flex flex-col h-full bg-surface border-r border-border w-full">
      {/* Logo */}
      <div className="flex items-center justify-between px-4 py-4 border-b border-border">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-cyan/10 border border-cyan/20 flex items-center justify-center glow-cyan">
            <Bot size={16} className="text-cyan" />
          </div>
          <div>
            <p className="text-sm font-semibold text-bright font-mono">AI Agent</p>
            <p className="text-xs text-dim">Multi-model chat</p>
          </div>
        </div>
        {mobile && (
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-lg text-dim hover:text-bright hover:bg-border transition-all"
          >
            <ChevronLeft size={18} />
          </button>
        )}
      </div>

      {/* New Chat */}
      <div className="px-3 py-3">
        <button
          onClick={onNew}
          className="
            w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl
            border border-dashed border-border-bright
            text-dim hover:text-bright hover:border-cyan/40 hover:bg-cyan/5
            transition-all duration-200 group text-sm
          "
        >
          <Plus size={15} className="group-hover:text-cyan transition-colors" />
          <span>New Chat</span>
        </button>
      </div>

      {/* Conversations */}
      <div className="flex-1 overflow-y-auto px-3 pb-3 space-y-1">
        {conversations.length === 0 ? (
          <div className="text-center py-8">
            <MessageSquare size={20} className="text-muted mx-auto mb-2" />
            <p className="text-xs text-dim">No conversations yet</p>
          </div>
        ) : (
          <>
            <p className="text-xs text-muted font-mono uppercase tracking-wider px-2 py-2">
              History
            </p>
            {conversations.map((c) => (
              <div
                key={c.id}
                onMouseEnter={() => setHoveredId(c.id)}
                onMouseLeave={() => setHoveredId(null)}
                className={`
                  relative group flex items-center gap-2 px-3 py-2.5 rounded-xl
                  cursor-pointer transition-all duration-150
                  ${activeId === c.id
                    ? "bg-cyan/8 border border-cyan/20 text-bright"
                    : "hover:bg-border text-soft hover:text-bright border border-transparent"
                  }
                `}
                onClick={() => {
                  if (editingId !== c.id) {
                    onSelect(c.id);
                    onClose?.();
                  }
                }}
              >
                <MessageSquare
                  size={13}
                  className={`flex-shrink-0 ${activeId === c.id ? "text-cyan" : "text-muted"}`}
                />

                {editingId === c.id ? (
                  <input
                    autoFocus
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") commitEdit();
                      if (e.key === "Escape") setEditingId(null);
                    }}
                    className="flex-1 bg-transparent text-sm text-bright outline-none border-b border-cyan/40 pb-0.5 min-w-0"
                    onClick={(e) => e.stopPropagation()}
                  />
                ) : (
                  <div className="flex-1 min-w-0">
                    <p className="text-sm truncate leading-tight">{c.title}</p>
                    <p className="text-xs text-muted font-mono">{timeAgo(c.updatedAt)}</p>
                  </div>
                )}

                {/* Actions */}
                {editingId === c.id ? (
                  <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                    <button onClick={commitEdit} className="text-cyan hover:text-cyan/80 p-0.5">
                      <Check size={13} />
                    </button>
                    <button onClick={() => setEditingId(null)} className="text-dim hover:text-soft p-0.5">
                      <X size={13} />
                    </button>
                  </div>
                ) : (
                  hoveredId === c.id && (
                    <div
                      className="flex items-center gap-0.5"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        onClick={() => startEdit(c)}
                        className="p-1 rounded text-muted hover:text-soft hover:bg-border-bright transition-all"
                      >
                        <Edit3 size={12} />
                      </button>
                      <button
                        onClick={() => onDelete(c.id)}
                        className="p-1 rounded text-muted hover:text-red-400 hover:bg-red-400/10 transition-all"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  )
                )}
              </div>
            ))}
          </>
        )}
      </div>

      {/* Footer */}
      <div className="px-4 py-3 border-t border-border">
        <p className="text-xs text-muted font-mono text-center">
          Powered by{" "}
          <a
            href="https://openrouter.ai"
            target="_blank"
            rel="noopener noreferrer"
            className="text-cyan/70 hover:text-cyan transition-colors"
          >
            OpenRouter
          </a>
        </p>
      </div>
    </div>
  );
}

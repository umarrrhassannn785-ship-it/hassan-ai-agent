"use client";

import { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism";
import { Copy, Check, User, Bot, ChevronDown, ChevronUp } from "lucide-react";
import { Message } from "@/types";
import { AVAILABLE_MODELS } from "@/types";

interface Props {
  message: Message;
  isStreaming?: boolean;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <button
      onClick={copy}
      className="flex items-center gap-1 px-2 py-1 rounded text-xs text-dim hover:text-soft hover:bg-border transition-all"
    >
      {copied ? <Check size={12} className="text-cyan" /> : <Copy size={12} />}
      {copied ? "Copied" : "Copy"}
    </button>
  );
}

export default function MessageBubble({ message, isStreaming }: Props) {
  const isUser = message.role === "user";
  const isEmpty = !message.content && isStreaming;
  const [collapsed, setCollapsed] = useState(false);
  const isLong = message.content.length > 1200;

  const modelName = message.model
    ? AVAILABLE_MODELS.find((m) => m.id === message.model)?.name ?? message.model
    : null;

  if (isUser) {
    return (
      <div className="flex justify-end px-4 py-2 animate-slide-up">
        <div className="flex items-start gap-3 max-w-[80%] flex-row-reverse">
          {/* Avatar */}
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan/30 to-cyan/10 border border-cyan/30 flex items-center justify-center flex-shrink-0">
            <User size={14} className="text-cyan" />
          </div>
          {/* Bubble */}
          <div className="bg-cyan/10 border border-cyan/20 rounded-2xl rounded-tr-sm px-4 py-3">
            <p className="text-sm text-bright leading-relaxed whitespace-pre-wrap break-words">
              {message.content}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start px-4 py-2 animate-slide-up">
      <div className="flex items-start gap-3 max-w-[88%] w-full">
        {/* Avatar */}
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-panel to-surface border border-border-bright flex items-center justify-center flex-shrink-0 mt-0.5">
          <Bot size={14} className="text-cyan" />
        </div>

        <div className="flex-1 min-w-0">
          {/* Model badge */}
          {modelName && (
            <p className="text-xs text-muted font-mono mb-1.5 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan/60" />
              {modelName}
            </p>
          )}

          {/* Content */}
          {isEmpty ? (
            <div className="thinking-dots flex items-center gap-1.5 py-2">
              <span className="w-2 h-2 rounded-full bg-cyan/60 inline-block" />
              <span className="w-2 h-2 rounded-full bg-cyan/60 inline-block" />
              <span className="w-2 h-2 rounded-full bg-cyan/60 inline-block" />
            </div>
          ) : (
            <div className="relative">
              <div
                className={`prose-chat text-sm text-soft leading-relaxed ${
                  collapsed ? "max-h-48 overflow-hidden" : ""
                }`}
              >
                <ReactMarkdown
                  remarkPlugins={[remarkGfm]}
                  components={{
                    code({ node, className, children, ...props }) {
                      const match = /language-(\w+)/.exec(className || "");
                      const isInline = !match;
                      if (isInline) {
                        return (
                          <code className={className} {...props}>
                            {children}
                          </code>
                        );
                      }
                      const codeString = String(children).replace(/\n$/, "");
                      return (
                        <div className="relative group/code my-3">
                          <div className="flex items-center justify-between bg-void/80 border border-border rounded-t-lg px-3 py-1.5">
                            <span className="text-xs text-muted font-mono">
                              {match[1]}
                            </span>
                            <CopyButton text={codeString} />
                          </div>
                          <SyntaxHighlighter
                            style={oneDark}
                            language={match[1]}
                            PreTag="div"
                            customStyle={{
                              margin: 0,
                              borderRadius: "0 0 8px 8px",
                              background: "#0d0f14",
                              border: "1px solid #1e2229",
                              borderTop: "none",
                              fontSize: "0.8rem",
                              lineHeight: "1.6",
                            }}
                          >
                            {codeString}
                          </SyntaxHighlighter>
                        </div>
                      );
                    },
                  }}
                >
                  {message.content}
                </ReactMarkdown>
                {isStreaming && message.content && (
                  <span className="cursor-blink" />
                )}
              </div>

              {/* Fade + expand for long messages */}
              {isLong && collapsed && (
                <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-void to-transparent" />
              )}

              {/* Collapse controls */}
              <div className="flex items-center justify-between mt-2">
                {isLong && (
                  <button
                    onClick={() => setCollapsed((p) => !p)}
                    className="flex items-center gap-1 text-xs text-dim hover:text-cyan transition-colors font-mono"
                  >
                    {collapsed ? (
                      <><ChevronDown size={12} /> Show more</>
                    ) : (
                      <><ChevronUp size={12} /> Show less</>
                    )}
                  </button>
                )}
                {!isStreaming && message.content && (
                  <div className="ml-auto">
                    <CopyButton text={message.content} />
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

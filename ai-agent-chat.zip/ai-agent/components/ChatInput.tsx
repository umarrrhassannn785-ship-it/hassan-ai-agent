"use client";

import { useState, useRef, useEffect, KeyboardEvent } from "react";
import { Send, Square, Paperclip } from "lucide-react";

interface Props {
  onSend: (content: string) => void;
  onStop: () => void;
  isStreaming: boolean;
  disabled?: boolean;
  placeholder?: string;
}

const SUGGESTIONS = [
  "Explain quantum entanglement simply",
  "Write a Python web scraper",
  "Debug my code step by step",
  "Create a marketing strategy",
];

export default function ChatInput({
  onSend,
  onStop,
  isStreaming,
  disabled,
  placeholder = "Message AI Agent...",
}: Props) {
  const [value, setValue] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 200) + "px";
  }, [value]);

  const handleSend = () => {
    const trimmed = value.trim();
    if (!trimmed || isStreaming || disabled) return;
    onSend(trimmed);
    setValue("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
  };

  const handleKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const canSend = value.trim().length > 0 && !isStreaming && !disabled;

  return (
    <div className="w-full px-4 pb-4 pt-2">
      {/* Suggestions (only when empty) */}
      {!value && !isStreaming && (
        <div className="flex flex-wrap gap-2 justify-center mb-3">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => {
                setValue(s);
                textareaRef.current?.focus();
              }}
              className="text-xs text-dim border border-border-bright rounded-full px-3 py-1.5
                hover:border-cyan/40 hover:text-cyan hover:bg-cyan/5
                transition-all duration-200 font-mono"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Input box */}
      <div className={`
        relative flex items-end gap-2 bg-panel border rounded-2xl px-4 py-3
        transition-all duration-200
        ${disabled ? "opacity-50 border-border" : "border-border-bright focus-within:border-cyan/40 focus-within:shadow-[0_0_0_2px_rgba(0,212,255,0.06)]"}
      `}>
        {/* Textarea */}
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKey}
          disabled={disabled || isStreaming}
          placeholder={placeholder}
          rows={1}
          className="
            flex-1 bg-transparent text-sm text-bright placeholder:text-muted
            resize-none outline-none leading-relaxed min-h-[24px]
            disabled:cursor-not-allowed font-sans
          "
          style={{ maxHeight: "200px" }}
        />

        {/* Actions */}
        <div className="flex items-center gap-1 flex-shrink-0 pb-0.5">
          {isStreaming ? (
            <button
              onClick={onStop}
              className="w-8 h-8 rounded-xl bg-red-500/20 border border-red-500/30 flex items-center justify-center
                text-red-400 hover:bg-red-500/30 transition-all active:scale-95"
            >
              <Square size={13} fill="currentColor" />
            </button>
          ) : (
            <button
              onClick={handleSend}
              disabled={!canSend}
              className={`
                w-8 h-8 rounded-xl flex items-center justify-center
                transition-all duration-200 active:scale-95
                ${canSend
                  ? "bg-cyan text-void hover:bg-cyan/90 shadow-[0_0_12px_rgba(0,212,255,0.3)]"
                  : "bg-border text-muted cursor-not-allowed"
                }
              `}
            >
              <Send size={13} />
            </button>
          )}
        </div>
      </div>

      <p className="text-center text-xs text-muted mt-2 font-mono">
        Enter to send · Shift+Enter for new line
      </p>
    </div>
  );
}

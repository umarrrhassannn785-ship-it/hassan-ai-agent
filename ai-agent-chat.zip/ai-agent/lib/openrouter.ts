import { Message } from "@/types";

const OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1";

export interface ChatCompletionOptions {
  model: string;
  messages: Pick<Message, "role" | "content">[];
  stream?: boolean;
  temperature?: number;
  max_tokens?: number;
}

export async function createChatCompletion(
  options: ChatCompletionOptions,
  apiKey: string
): Promise<Response> {
  const { model, messages, stream = true, temperature = 0.7, max_tokens = 2048 } = options;

  const response = await fetch(`${OPENROUTER_BASE_URL}/chat/completions`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "HTTP-Referer": process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
      "X-Title": "AI Agent Chat",
    },
    body: JSON.stringify({
      model,
      messages: messages.map(({ role, content }) => ({ role, content })),
      stream,
      temperature,
      max_tokens,
    }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(
      error?.error?.message || `OpenRouter API error: ${response.status}`
    );
  }

  return response;
}

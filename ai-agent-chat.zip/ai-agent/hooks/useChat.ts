"use client";

import { useState, useCallback, useRef } from "react";
import { v4 as uuidv4 } from "uuid";
import { Message, Conversation } from "@/types";

const STORAGE_KEY = "ai_agent_conversations";
const API_KEY_STORAGE = "ai_agent_api_key";

function loadConversations(): Conversation[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return parsed.map((c: Conversation) => ({
      ...c,
      createdAt: new Date(c.createdAt),
      updatedAt: new Date(c.updatedAt),
      messages: c.messages.map((m: Message) => ({
        ...m,
        timestamp: new Date(m.timestamp),
      })),
    }));
  } catch {
    return [];
  }
}

function saveConversations(conversations: Conversation[]) {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
}

export function useChat() {
  const [conversations, setConversations] = useState<Conversation[]>(() =>
    loadConversations()
  );
  const [activeId, setActiveId] = useState<string | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [apiKey, setApiKeyState] = useState<string>(() => {
    if (typeof window === "undefined") return "";
    return localStorage.getItem(API_KEY_STORAGE) || "";
  });
  const [selectedModel, setSelectedModel] = useState("openai/gpt-4o-mini");
  const abortRef = useRef<AbortController | null>(null);

  const activeConversation = conversations.find((c) => c.id === activeId) ?? null;

  const saveApiKey = useCallback((key: string) => {
    setApiKeyState(key);
    if (typeof window !== "undefined") {
      localStorage.setItem(API_KEY_STORAGE, key);
    }
  }, []);

  const newConversation = useCallback(() => {
    const convo: Conversation = {
      id: uuidv4(),
      title: "New Chat",
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      model: selectedModel,
    };
    setConversations((prev) => {
      const updated = [convo, ...prev];
      saveConversations(updated);
      return updated;
    });
    setActiveId(convo.id);
    return convo.id;
  }, [selectedModel]);

  const deleteConversation = useCallback(
    (id: string) => {
      setConversations((prev) => {
        const updated = prev.filter((c) => c.id !== id);
        saveConversations(updated);
        return updated;
      });
      if (activeId === id) {
        setActiveId(null);
      }
    },
    [activeId]
  );

  const renameConversation = useCallback((id: string, title: string) => {
    setConversations((prev) => {
      const updated = prev.map((c) => (c.id === id ? { ...c, title } : c));
      saveConversations(updated);
      return updated;
    });
  }, []);

  const sendMessage = useCallback(
    async (content: string) => {
      setError(null);
      let convId = activeId;

      if (!convId) {
        convId = uuidv4();
        const convo: Conversation = {
          id: convId,
          title: content.slice(0, 50) || "New Chat",
          messages: [],
          createdAt: new Date(),
          updatedAt: new Date(),
          model: selectedModel,
        };
        setConversations((prev) => {
          const updated = [convo, ...prev];
          saveConversations(updated);
          return updated;
        });
        setActiveId(convId);
      }

      const userMsg: Message = {
        id: uuidv4(),
        role: "user",
        content,
        timestamp: new Date(),
      };

      let currentMessages: Message[] = [];

      setConversations((prev) => {
        const updated = prev.map((c) => {
          if (c.id !== convId) return c;
          const msgs = [...c.messages, userMsg];
          currentMessages = msgs;
          const title =
            c.messages.length === 0 ? content.slice(0, 50) || "New Chat" : c.title;
          return { ...c, messages: msgs, title, updatedAt: new Date() };
        });
        saveConversations(updated);
        return updated;
      });

      // Placeholder assistant message
      const assistantId = uuidv4();
      const assistantMsg: Message = {
        id: assistantId,
        role: "assistant",
        content: "",
        timestamp: new Date(),
        model: selectedModel,
      };

      setConversations((prev) => {
        const updated = prev.map((c) => {
          if (c.id !== convId) return c;
          return { ...c, messages: [...c.messages, assistantMsg] };
        });
        return updated;
      });

      setIsStreaming(true);
      abortRef.current = new AbortController();

      try {
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [...currentMessages, userMsg].map(({ role, content }) => ({
              role,
              content,
            })),
            model: selectedModel,
            apiKey,
          }),
          signal: abortRef.current.signal,
        });

        if (!response.ok) {
          const data = await response.json();
          throw new Error(data.error || "Request failed");
        }

        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let accumulated = "";

        if (reader) {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value, { stream: true });
            const lines = chunk.split("\n");

            for (const line of lines) {
              if (line.startsWith("data: ")) {
                const data = line.slice(6).trim();
                if (data === "[DONE]") continue;
                try {
                  const parsed = JSON.parse(data);
                  const delta = parsed.choices?.[0]?.delta?.content;
                  if (delta) {
                    accumulated += delta;
                    const snap = accumulated;
                    setConversations((prev) => {
                      const updated = prev.map((c) => {
                        if (c.id !== convId) return c;
                        return {
                          ...c,
                          messages: c.messages.map((m) =>
                            m.id === assistantId ? { ...m, content: snap } : m
                          ),
                        };
                      });
                      return updated;
                    });
                  }
                } catch {
                  // skip malformed chunks
                }
              }
            }
          }
        }

        // Persist final
        setConversations((prev) => {
          const updated = prev.map((c) => {
            if (c.id !== convId) return c;
            return {
              ...c,
              messages: c.messages.map((m) =>
                m.id === assistantId ? { ...m, content: accumulated } : m
              ),
              updatedAt: new Date(),
            };
          });
          saveConversations(updated);
          return updated;
        });
      } catch (err: unknown) {
        if (err instanceof Error && err.name === "AbortError") return;
        const msg = err instanceof Error ? err.message : "Something went wrong";
        setError(msg);
        setConversations((prev) => {
          const updated = prev.map((c) => {
            if (c.id !== convId) return c;
            return {
              ...c,
              messages: c.messages.map((m) =>
                m.id === assistantId
                  ? { ...m, content: `⚠️ Error: ${msg}` }
                  : m
              ),
            };
          });
          saveConversations(updated);
          return updated;
        });
      } finally {
        setIsStreaming(false);
      }
    },
    [activeId, apiKey, selectedModel]
  );

  const stopStreaming = useCallback(() => {
    abortRef.current?.abort();
    setIsStreaming(false);
  }, []);

  const clearError = useCallback(() => setError(null), []);

  return {
    conversations,
    activeConversation,
    activeId,
    setActiveId,
    isStreaming,
    error,
    clearError,
    apiKey,
    saveApiKey,
    selectedModel,
    setSelectedModel,
    newConversation,
    deleteConversation,
    renameConversation,
    sendMessage,
    stopStreaming,
  };
}

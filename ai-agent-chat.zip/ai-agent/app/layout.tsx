import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Agent — Multi-Model Chat",
  description: "A powerful AI chat interface powered by OpenRouter — GPT-4o, Claude, Gemini, Llama & more.",
  keywords: ["AI", "chat", "GPT-4", "Claude", "OpenRouter", "chatbot"],
  openGraph: {
    title: "AI Agent",
    description: "Multi-model AI chat powered by OpenRouter",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className="bg-void text-bright antialiased dark">
        {children}
      </body>
    </html>
  );
}

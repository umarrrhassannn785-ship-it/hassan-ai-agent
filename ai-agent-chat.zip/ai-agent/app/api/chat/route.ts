import { NextRequest, NextResponse } from "next/server";
import { createChatCompletion } from "@/lib/openrouter";

export const runtime = "edge";

export async function POST(req: NextRequest) {
  try {
    const { messages, model, apiKey } = await req.json();

    if (!apiKey) {
      return NextResponse.json(
        { error: "OpenRouter API key is required. Add it in Settings." },
        { status: 401 }
      );
    }

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Messages are required." }, { status: 400 });
    }

    const response = await createChatCompletion(
      {
        model: model || "openai/gpt-4o-mini",
        messages,
        stream: true,
        temperature: 0.7,
        max_tokens: 4096,
      },
      apiKey
    );

    // Forward the stream directly
    return new Response(response.body, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error occurred";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export type Role = "user" | "assistant" | "system";

export interface Message {
  id: string;
  role: Role;
  content: string;
  timestamp: Date;
  model?: string;
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
  model: string;
}

export interface OpenRouterModel {
  id: string;
  name: string;
  context_length: number;
  pricing: {
    prompt: string;
    completion: string;
  };
}

export const AVAILABLE_MODELS: OpenRouterModel[] = [
  {
    id: "openai/gpt-4o",
    name: "GPT-4o",
    context_length: 128000,
    pricing: { prompt: "0.000005", completion: "0.000015" },
  },
  {
    id: "openai/gpt-4o-mini",
    name: "GPT-4o Mini",
    context_length: 128000,
    pricing: { prompt: "0.00000015", completion: "0.0000006" },
  },
  {
    id: "anthropic/claude-3.5-sonnet",
    name: "Claude 3.5 Sonnet",
    context_length: 200000,
    pricing: { prompt: "0.000003", completion: "0.000015" },
  },
  {
    id: "anthropic/claude-3-haiku",
    name: "Claude 3 Haiku",
    context_length: 200000,
    pricing: { prompt: "0.00000025", completion: "0.00000125" },
  },
  {
    id: "google/gemini-pro-1.5",
    name: "Gemini 1.5 Pro",
    context_length: 1000000,
    pricing: { prompt: "0.0000025", completion: "0.0000075" },
  },
  {
    id: "meta-llama/llama-3.1-70b-instruct",
    name: "Llama 3.1 70B",
    context_length: 131072,
    pricing: { prompt: "0.00000052", completion: "0.00000075" },
  },
  {
    id: "mistralai/mistral-large",
    name: "Mistral Large",
    context_length: 128000,
    pricing: { prompt: "0.000002", completion: "0.000006" },
  },
];
